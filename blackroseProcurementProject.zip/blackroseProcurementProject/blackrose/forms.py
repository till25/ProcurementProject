from django.forms import ModelForm
from .models import *
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User 
from django import forms



from django import forms

from .models import (Vendor,
Product,
PurchaseRequest,
PurchaseOrder)



class VendorForm(forms.ModelForm):

    class Meta:
        model = Vendor
        fields = ('name', 'phone','email','address',)


class ProductForm(forms.ModelForm):

    class Meta:
        model = Product
        fields = ('name', 'price','description',)

class PurchaseRequestForm(forms.ModelForm):

    class Meta:
        model = PurchaseRequest
        fields = ('item_name','department','price', 'quantity','description','delivery_date',)


class PurchaseOrderForm(forms.ModelForm):

    class Meta:
        model = PurchaseOrder
        fields = ('pr_no', 'vendor','status',)

class PurchaseOrderForm(ModelForm):
    class Meta:
        model = PurchaseOrder
        fields = '__all__'

class PurchaseRequestForm(ModelForm):
    class Meta:
        model = PurchaseRequest
        fields = '__all__'

class ProductForm(ModelForm):
    class Meta:
        model = Product
        fields = '__all__'

class VendorForm(ModelForm):
    class Meta:
        model = Vendor
        fields = ['name','phone','email','address']

class CreateUserForm(UserCreationForm):
	class Meta:
		model = User 
		fields = ['username','email','password1','password2']