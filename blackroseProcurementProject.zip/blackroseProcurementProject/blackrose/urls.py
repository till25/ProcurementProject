from django.urls import path
from .views import VendorDeleteView
from . import views 

urlpatterns = [
    path('', views.home, name='dashboard'),
    # VENDOR URLS
    path('vendors/',views.vendors, name='vendors'),  
    path('vendor/new/', views.vendor_add, name='vendor_add'),
    path('vendor/<int:pk>/',views.vendor_detail, name='vendor_detail'),
    path('vendor/<int:pk>/edit', views.vendor_edit, name='vendor_edit'),
    path('vendor/<int:pk>/delete/', VendorDeleteView.as_view(), name='vendor_delete'),
  
    #PURCHASE ORDER URLS
    path('purchase-orders/',views.purchase_orders, name='purchase_orders'),  
    path('purchase-order/new/', views.purchase_order_add, name='purchase_order_add'),
    path('purchase-order-detail/<int:pk>/',views.purchase_order_detail, name='purchase_order_detail'),
    path('purchase-order/<int:pk>/edit', views.purchase_order_edit, name='purchase_order_edit'),
    path('purchase-order/<int:pk>/delete/', views.PurchaseOrderDeleteView.as_view(), name='purchase_order_delete'),
 
    # PURCHASE REQUEST URLS
    path('purchase-requests/',views.purchase_requests, name='purchase_requests'),  
    path('purchase-requests/new/', views.purchase_request_add, name='purchase_request_add'),
    path('purchase-requests-detail/<int:pk>/',views.purchase_request_detail, name='purchase_request_detail'),
    path('purchase-requests/<int:pk>/edit', views.purchase_request_edit, name='purchase_request_edit'),
    path('purchase-requests/<int:pk>/delete/', views.PurchaseRequestDeleteView.as_view(), name='purchase_request_delete'),
 
]