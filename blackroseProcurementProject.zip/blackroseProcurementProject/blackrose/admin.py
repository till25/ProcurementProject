from django.contrib import admin

from .models import Vendor,Product,PurchaseRequest,PurchaseOrder


admin.site.register(Vendor)
admin.site.register(Product)
admin.site.register(PurchaseRequest)
admin.site.register(PurchaseOrder)