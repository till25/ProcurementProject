from django.shortcuts import render,redirect,get_object_or_404
from .models import *
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.auth.decorators import login_required
from .forms import  Vendor,Product,PurchaseRequest,PurchaseOrder
from django.views.generic import ListView, DetailView,CreateView,UpdateView,DeleteView
from .forms import (VendorForm,
PurchaseRequestForm,
PurchaseOrderForm)

# PURCHASE ORDER VIEWS
def purchase_orders(request):
    purchase_orders = PurchaseOrder.objects.all()
    context = {
        'purchase_orders':purchase_orders
    }
    return render(request,'blackrose/po_data.html', context)
@login_required
def purchase_order_add(request):
    if request.method == "POST":
        form = PurchaseOrderForm(request.POST)
        if form.is_valid():
            purchase_order = form.save(commit=False)
            purchase_order.save()
            return redirect('purchase_order_detail', pk=purchase_order.pk)
    else:
        form = PurchaseOrderForm()
    return render(request, 'blackrose/po_add.html', {'form': form})

def purchase_order_detail(request,pk):
    purchase_order = get_object_or_404(PurchaseOrder, pk=pk)
    return render(request, 'blackrose/po_detail.html', {'purchase_order': purchase_order})
@login_required
def purchase_order_edit(request,pk):
    purchase_order = get_object_or_404(PurchaseOrder, pk=pk)
    if request.method == "POST":
        form = PurchaseOrderForm(request.POST, instance=purchase_order)
        if form.is_valid():
            purchase_order = form.save(commit=False)
            # vendor.published_date = timezone.now()
            purchase_order.save()
            return redirect('purchase_order_detail', pk=purchase_order.pk)
    else:
        form = PurchaseOrderForm(instance=purchase_order)
    return render(request, 'blackrose/po_edit.html', {'form': form, 'purchase_order':purchase_order})
@login_required
class PurchaseOrderDeleteView(LoginRequiredMixin,DeleteView):
    model = PurchaseOrder
    success_url ='/'
   
# PURCHASE REQUEST VIEWS
def purchase_requests(request):
    purchase_requests = PurchaseRequest.objects.all()
    context = {
        'purchase_requests':purchase_requests
    }
    return render(request,'blackrose/pr_data.html', context)

@login_required
def purchase_request_add(request):
    if request.method == "POST":
        form = PurchaseRequestForm(request.POST)
        if form.is_valid():
            purchase_request = form.save(commit=False)
            # vendor.author = request.user
            purchase_request.save()
            return redirect('purchase_request_detail', pk=purchase_request.pk)
    else:
        form = PurchaseRequestForm()
    return render(request, 'blackrose/pr_add.html', {'form': form})

def purchase_request_detail(request,pk):
    purchase_request = get_object_or_404(PurchaseRequest, pk=pk)
    return render(request, 'blackrose/pr_detail.html', {'purchase_request': purchase_request})
@login_required
def purchase_request_edit(request,pk):
    purchase_request = get_object_or_404(PurchaseRequest, pk=pk)
    if request.method == "POST":
        form = PurchaseRequestForm(request.POST, instance=purchase_request)
        if form.is_valid():
            purchase_request = form.save(commit=False)
            purchase_request.requester = request.user
            # vendor.published_date = timezone.now()
            purchase_request.save()
            return redirect('purchase_request_detail', pk=purchase_request.pk)
    else:
        form = PurchaseRequestForm(instance=purchase_request)
    return render(request, 'blackrose/pr_edit.html', {'form': form, 'purchase_request':purchase_request})
@login_required
class PurchaseRequestDeleteView(LoginRequiredMixin,DeleteView):
    model = PurchaseRequest
    success_url ='/'

# VENDOR VIEWS
def vendors(request):
    vendors = Vendor.objects.all()
    context = {
        'vendors':vendors
    }
    return render(request,'blackrose/vendor_data.html', context)
@login_required
def vendor_add(request):
    if request.method == "POST":
        form = VendorForm(request.POST)
        if form.is_valid():
            vendor = form.save(commit=False)
            vendor.save()
            return redirect('vendor_detail', pk=vendor.pk)
    else:
        form = VendorForm()
    return render(request, 'blackrose/vendor_add.html', {'form': form})

def vendor_detail(request,pk):
    vendor = get_object_or_404(Vendor, pk=pk)
    return render(request, 'blackrose/vendor_detail.html', {'vendor': vendor})
@login_required
def vendor_edit(request,pk):
    vendor = get_object_or_404(Vendor, pk=pk)
    if request.method == "POST":
        form = VendorForm(request.POST, instance=vendor)
        if form.is_valid():
            vendor = form.save(commit=False)
            # vendor.author = request.user
            # vendor.published_date = timezone.now()
            vendor.save()
            return redirect('vendor_detail', pk=vendor.pk)
    else:
        form = VendorForm(instance=vendor)
    return render(request, 'blackrose/vendor_edit.html', {'form': form, 'vendor':vendor})
@login_required
class VendorDeleteView(LoginRequiredMixin,DeleteView):
    model = Vendor
    success_url ='/'
   
# def vendor_delete(request,pk):
#     vendor = get_object_or_404(Vendor, pk=pk)
#     vendor.delete()
#     return redirect('dashboard')

# OTHER VIEWS
def home(request):
    vendors = Vendor.objects.all()
    vendors_count = Vendor.objects.count()
    products = Product.objects.all()
    requisitions = PurchaseRequest.objects.all()
    purchase_orders = PurchaseOrder.objects.all()
    requisitions_count = PurchaseRequest.objects.count()
    purchase_orders_count = PurchaseOrder.objects.count()

    context = {
        'vendors':vendors,
        'vendors_count':vendors_count,
        'products':products,
        'requisitions':requisitions,
        'purchase_orders':purchase_orders,
        'requisitions_count' :requisitions_count,
        'purchase_orders_count' :purchase_orders_count,
    }
    return render(request,'blackrose/dashboard.html',context)
