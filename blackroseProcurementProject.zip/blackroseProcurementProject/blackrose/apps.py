from django.apps import AppConfig


class BlackroseConfig(AppConfig):
    name = 'blackrose'
