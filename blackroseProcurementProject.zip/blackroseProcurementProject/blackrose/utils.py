import uuid

def po_number():
    no = str(uuid.uuid4()).split('-')[0].upper()
    purchase_order_number = 'PO-'+ no
    return purchase_order_number

def pr_number():
    no = str(uuid.uuid4()).split('-')[0].upper()
    purchase_request_number = 'PR-'+ no
    return purchase_request_number
